package spongeblockcz.FFMOD.Item;

import net.minecraft.item.Item;

public interface ItemModelProvider {

	void registerItemModel(Item item);
}

